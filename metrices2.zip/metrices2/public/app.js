var app=angular.module('App', ['ngMaterial','ngAnimate','ngMessages']);
// var app1=angular.module('main'['ui.router'])
// app1.config(function($stateProvider,$urlRouterProvider) {


app.controller('demoController', function($scope,$http) {

  $scope.user = null;
$scope.users = null;
$scope.operations =[
  { id: 1, name: 'Addition' },
  { id: 2, name: 'Subtraction' },
  { id: 3, name: 'Multiplication' },
  { id: 4, name: 'Division' }
];
  $http.get('http://localhost:8080/header').then(function(data){
    $scope.header=data.data;
  });
$scope.loadoperation = function() {
  $http.get('http://localhost:8080/new/'+$scope.currentop.id+'/'+$scope.lefthead+'/'+$scope.righthead).then(function(data) {
    console.log(data.data);
    $scope.myrecord=data.data;
    var a=[];
    a=$scope.myrecord['a'];
    console.log(a);
    var b=[];
    b=$scope.myrecord['b'];
    var c=[];
    c=$scope.myrecord['result'];
    $scope.viewdata=[];
    for (var i = 0; i < a.length; i++) {
      var viewobj={};
      viewobj.a=a[i];
      viewobj.b=b[i];
      viewobj.c=c[i];
      $scope.viewdata.push(viewobj);
    }
    // console.log($scope.viewdata);

    // $scope.tooltipFunc = function(branch) {
    // 	return branch.name;
    // };
        // $scope.myStyle="width:150px;height:100px;"
      });

};
  $scope.hi="hi";


		 });
